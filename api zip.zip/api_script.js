var request = new XMLHttpRequest();

request.open('GET', "https://hplussport.com/api/products/qty/5");
request.onload = function() {
    var response = request.response;
    var parsedDat = JSON.parse(response);
    console.log(parsedDat);
    var descri=parsedDat[0].description ; 
    console.log(descri) ;

    var prod = document.createElement('li'); 
    prod.innerHTML = descri;
    document.body.appendChild(prod);

        var decrimage=parsedDat[0].image ; 
    var prods = document.createElement('img'); 
    prods.setAttribute('src',decrimage)
    document.body.appendChild(prods);
}

request.send();
