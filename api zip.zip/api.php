<!DOCTYPE html>
<html>

<head>
    <title>H+ Sport API</title>
    <script src="api_script.js"></script>
</head>

<body>
    <h1>Working with the H+ Sport API</h1>
</body>

</html>